import React from 'react'

const page = () => {
  return (
    <div>
      This is Equity
    </div>
  )
}

export default page

